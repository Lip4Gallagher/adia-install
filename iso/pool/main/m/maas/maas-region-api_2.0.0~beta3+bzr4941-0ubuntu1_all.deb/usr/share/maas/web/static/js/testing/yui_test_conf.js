var YUI_config = {
    debug: true,
    combine: false,
    filter: 'raw'
};
