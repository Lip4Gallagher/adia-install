from landscape.patch import UpgradeManager

upgrade_manager = UpgradeManager()
