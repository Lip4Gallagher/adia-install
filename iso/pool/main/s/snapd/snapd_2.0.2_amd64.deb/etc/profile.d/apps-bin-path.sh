# Expand the $PATH to include /snaps/bin which is what snappy applications
# use
PATH=$PATH:/snap/bin
